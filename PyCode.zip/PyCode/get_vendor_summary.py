import sqlite3
import pandas as pd
import logging
import time
from ingestion_db import ingest_db

logging.basicConfig(
    filename="logs/get_vendor_summary.log",
    level=logging.DEBUG,
    format= "%(asctime)s - %(levelname) - %(message)s",
    filemode = "a"
)
logging.getLogger().handlers[0].setLevel(logging.INFO)  # File logs only

def create_vendor_summary(conn):
    start=time.time()
    Vendor_Sales_Summary = pd.read_sql_query("""With FreightSummary AS (
    SELECT 
        VendorNumber, 
        Sum(Freight) as TotalFreightCost 
    FROM vendor_invoice 
    GROUP BY VendorNumber
    ),

    PurchaseSummary AS ( 
    SELECT 
        p.VendorNumber, 
        p.VendorName, 
        p.Brand, 
        p.Description,
        p.PurchasePrice, 
        pp.Volume,
        pp.price as ActualPrice,
        SUM(p.Quantity) as TotalPurchaseQuantity,
        SUM(p.Dollars) as TotalPurchaseDollars
    FROM purchases p
    JOIN purchase_prices pp
    ON p.Brand = pp.Brand
    Where p.purchasePrice>0
    Group By p.VendorNumber, p.Brand, p.Description, p.PurchasePrice, pp.Price, pp.Volume
    ),

    SalesSummary AS(SELECT 
    VendorNo,
    Brand,
        SUM(SalesQuantity) as TotalSalesQuantity,
        SUM(SalesPrice) as TotalSalesPrice,
        SUM(SalesDollars) as TotalSalesDollars,
        SUM(ExciseTax) as TotalExciseTax
    FROM sales
    GROUP BY VendorNo, Brand
    )

    SELECT
        ps.VendorNumber, 
        ps.VendorName,
        ps.Brand, 
        ps.Description,
        ps.PurchasePrice,
        ps.ActualPrice,
        ps.volume,
        ps.TotalPurchaseQuantity,
        ps.TotalPurchaseDollars,
        ss.TotalSalesQuantity,
        ss.TotalSalesDollars,
        ss.TotalSalesPrice,
        ss.TotalExciseTax,
        fs.TotalFreightCost 
    FROM PurchaseSummary ps
    LEFT JOIN SalesSummary ss
        ON ps.VendorNumber = ss.VendorNo
        AND ps.Brand= ss.Brand
    LEFT JOIN FreightSummary fs
        ON ps.VendorNumber= fs.VendorNumber
    ORDER BY TotalPurchaseDollars DESC""",conn)
    end=time.time()
    Time_Taken = (end - start)/60 

    return Vendor_Sales_Summary

def clean_data(df):
    # changing datatype to float
    df['Volume'] =df['Volume'].astype('float64')
    # filling missing value with 0
    df.fillna(0, inplace = True)
    # removing spaces from categorical columns
    df['VendorName'] =df['VendorName'].str.strip()
    df['Description'] =df['Description'].str.strip()

    return df

def new_column(df):
    df['GrossProfit'] = df['TotalSalesDollars']-df['TotalPurchaseDollars']
    df['ProfitMargin'] = (df['GrossProfit']/df['TotalSalesDollars'])*100
    df['StockTurnover'] = df['TotalSalesQuantity']/df['TotalPurchaseQuantity'] 
    df['SalesToPurchaseRatio']= df['TotalSalesDollars']/ df['TotalPurchaseDollars']

    return df
if __name__ == '__main__':
    # Creating dataabse connection
    conn = sqlite3.connect('inventory.db')

    logging.info('Creating Vendor Summary Table............')
    summary_df = create_vendor_summary(conn)
    logging.info(summary_df.head())
    
    logging.info('Cleaning Data.............')
    clean_df = clean_data(summary_df)
    logging.info(clean_df).head())

    logging.info('Adding New Features..........')
    new_df = new_column(clean_df)
    logging.info(new_df.head())

    logging.info('Ingestion Data..........')
    ingest_db(new_df, 'Vendor_Sales_Summary',conn)
    Logging.info('.'*20,'Completed','.'*20)









    