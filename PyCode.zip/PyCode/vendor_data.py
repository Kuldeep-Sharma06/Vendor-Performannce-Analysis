import pandas as pd
import os
import time
from sqlalchemy import create_engine
import logging

# Configure logging
logging.basicConfig(
    filename="logs/ingestion_db.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="a"
)
logging.getLogger().handlers[0].setLevel(logging.INFO)  # File logs only

# Create database engine
engine = create_engine('sqlite:///inventory.db')

def ingest_db(df, table_name, engine):
    """Ingest DataFrame into SQLite DB"""
    df.to_sql(table_name, con=engine, if_exists="replace", index=False)

def load_raw_data():
    """Load all CSVs from data folder into database"""
    start = time.time()
    
    for file in os.listdir('data'):
        if file.endswith('.csv'):
            df = pd.read_csv(os.path.join('data', file))
            logging.info(f'Ingesting {file} into database')
            ingest_db(df, file[:-4], engine)
    
    end = time.time()
    total_time = (end - start) / 60
    logging.info('Ingestion complete')
    logging.info(f'Total Time Taken: {total_time:.2f} minutes')

if __name__ == '__main__':
    load_raw_data()
